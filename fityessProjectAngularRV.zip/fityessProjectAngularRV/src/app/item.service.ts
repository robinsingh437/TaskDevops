import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ItemService {

  constructor(private http: HttpClient) { }

  // Display

  getSportsWearItems() {
    return this.http.get('http://localhost:55575/api/sportswears')
  }

  getGearItems() {
    return this.http.get('http://localhost:55575/api/gears')
  }

  // display by ID
  getSportsWearById(itemId:string){
    return this.http.get('http://localhost:55575/api/sportswears/'+itemId)
  }
 
  getGearById(itemId:string){
    return this.http.get('http://localhost:55575/api/gears/'+itemId)
  }

  //post item

  postGearData(gear:any){
    return this.http.post('http://localhost:55575/api/gears/', gear);
  }
 
  postSportsWearData(item:any){
    return this.http.post('http://localhost:55575/api/sportswears/', item);
  }

  //update item

  putSportsWearData(item:any,itemId:string){
    return this.http.put('http://localhost:55575/api/sportswears/'+itemId, item);
  }
 
  putGearData(gear:any,itemId:string){
    return this.http.put('http://localhost:55575/api/gears/'+itemId, gear);
  }

  //delete item

  deleteGearItem(itemId:string){
    return this.http.delete('http://localhost:55575/api/gears/'+itemId);
  }

  deleteSportsWearItem(itemId:string){
    return this.http.delete('http://localhost:55575/api/sportswears/'+itemId);
  }

  // men display

  getMenItems(){
    return this.http.get('http://localhost:55575/api/menSportswear/')
  }
  getMenItemsByCat(id:string){
    return this.http.get('http://localhost:55575/api/menSportswear/' + id) 
  }
  getWomenItems(){
    return this.http.get('http://localhost:55575/api/womenSportswear/')
  }
  getWomenItemsByCat(id:string){
    return this.http.get('http://localhost:55575/api/womenSportswear/' + id) 
  }

}
