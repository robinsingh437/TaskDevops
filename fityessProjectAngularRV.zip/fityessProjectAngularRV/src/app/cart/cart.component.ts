import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartService } from '../cart.service';
import { DataserviceService } from '../dataservice.service';
import { ItemService } from '../item.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cartItems: any;
  items: any;
  cartPrice: number = 0;

  constructor(private cart: CartService, private item: ItemService, private rt: Router, private data: DataserviceService) {

    this.cart.getCart().subscribe(c => {
      this.cartItems = c;
      for (let i = 0; i < this.cartItems.length; i++) {
        this.cartPrice += this.cartItems[i].totalPrice;
      }
    });

    //this.item.getGearItems().subscribe(i=>this.items=i);
  }

  ngDoCheck() {
    // console.log(this.cartItems);
  }
  ngOnInit(): void {
  }
  removeCartItem(id: any, idx: number) {

    this.cart.deleteCart(id).subscribe(c => {

      this.cartPrice -= this.cartItems[idx].totalPrice;
      delete this.cartItems[idx];

      this.data.cartItems--;
      sessionStorage.removeItem('Items-In-Cart');
      sessionStorage.setItem('Items-In-Cart', JSON.stringify(this.data.cartItems));

    });

  }


  placeOrder(cartTotal: any) {

    this.data.amount = cartTotal;

    // console.log(this.data.amount);

    this.rt.navigate(['../order'])

  }
}
