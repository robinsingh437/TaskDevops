import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor(private http: HttpClient) { }

  postCartItem(user: any) {
    return this.http.post('http://localhost:55575/api/Carts/', user)
  }
  getCart() {
    return this.http.get('http://localhost:55575/api/Carts/' + sessionStorage.getItem('Active User')?.replace(/"/g, ''));
  }
  deleteCart(cartId:any){
    return this.http.delete('http://localhost:55575/api/Carts/' + cartId)
  }
}
