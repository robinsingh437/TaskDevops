import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataserviceService {

  tokenName:string='';
  tokenUserId:string='';
  amount:number=0;
  cartItems:number=0;
  role:string='';

  constructor() { }
}
