import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Md5 } from 'ts-md5';
import { UserService } from '../user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  submitted: boolean = false;
  userForm: FormGroup;
  constructor(private fb: FormBuilder, private user: UserService, private rt: Router) {
    this.userForm = this.fb.group({
      firstName: new FormControl("",
        Validators.compose([
          Validators.required,
          Validators.pattern('[a-z A-Z]+')
        ])),
      lastName: new FormControl("",
        Validators.compose([
          Validators.required,
          Validators.pattern('[a-z A-Z]+')
        ])),
      gender: new FormControl("",
        Validators.required),
      emailId: new FormControl("",
        Validators.compose([
          Validators.required,
          Validators.pattern("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$")
        ])),
      phoneNumber: new FormControl("",
        Validators.compose([
          Validators.required,
          Validators.pattern('\\d{10}')
        ])),
      address: new FormControl("", Validators.required),
      city: new FormControl("", Validators.required),
      country: new FormControl("", Validators.required),
      userId: new FormControl("",
        Validators.compose([
          Validators.required,
          Validators.minLength(5)
        ])),
      pass: new FormControl("", Validators.compose([
        Validators.required,
        Validators.minLength(5)
      ])),
      confPass: new FormControl("", Validators.required)
    });
  }

  ngOnInit(): void { }

  pass: string = "";
  cpass: string = "";
  ngDoCheck() {
    // if(this.pass==this.cpass){
    //   console.log("same")
    // }
    // else{
    //   console.log("not same")
    // }
  }

  onSubmit(data: any) {
    this.submitted = true;

    const md5 = new Md5();
    data.pass = md5.appendStr(data.pass).end();
    // console.log(md5.appendStr(data.pass).end())
    // console.log(data.pass)

    this.user.postUserData(data).subscribe(p => {
      // console.log(p);
    });

    alert("Registeration Successful")
    this.rt.navigate(['../login']);
  }

  // closeAlert() {
  //   this.submitted = false;
  //   this.rt.navigate(['/login']);
  // }

}
