import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataserviceService } from '../dataservice.service';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {

  orderForm: FormGroup;

  orderObject: object = {}
  shipAddress: string = "";
  totalAmountFinal: number;
  OrderId: any = 0;
  orderPlaced: boolean = false;


  constructor(private order: OrderService, private fb: FormBuilder, private data: DataserviceService, private rt: Router) {
    // debugger;
    this.totalAmountFinal = data.amount;
    this.orderForm = this.fb.group({
      shippingAddress: ["", Validators.required],
      paymentMethod: ["COD", Validators.required],
      amount: [this.totalAmountFinal]
    });
  }

  ngOnInit(): void {

    if (this.data.amount == 0) {
      alert("you've refreshed the page. Going Back to Cart.")
      this.rt.navigate(['../cart'])
    }

  }

  onSubmit(orderData: any) {

    // if (this.data.amount == 0) {
    //   alert("you've refreshed the page. Going Back to Cart.")
    //   this.rt.navigate(['../cart'])
    // }

    if (this.data.amount > 0) {
      this.orderObject = {

        shippingAddress: orderData.shippingAddress,
        paymentMethod: orderData.paymentMethod,
        amount: orderData.amount,
        userId: this.data.tokenUserId
      }
      // console.log(this.orderObject);

      this.order.postOrders(this.orderObject).subscribe(o => {
        this.OrderId = o;
        this.data.cartItems = 0;

        sessionStorage.removeItem('Items-In-Cart');
        sessionStorage.setItem('Items-In-Cart',JSON.stringify(this.data.cartItems));
        this.orderPlaced = true;
      });
    }

 
  }

}
