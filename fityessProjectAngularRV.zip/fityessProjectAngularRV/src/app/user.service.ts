import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  userApiLink:string='http://localhost:55575/api/Users/'
  constructor(private http:HttpClient) { }

  postUserData(user:any){
    return this.http.post(this.userApiLink, user);
  }
  findUser(userId:string){
    return this.http.get(this.userApiLink + userId);
  }
  getUser(userId:string, password:string){
    return this.http.get(this.userApiLink + userId+ "?password="+ password);
    // http://localhost:53393/api/users1/vardan?password=1fafa97365b509d810f92b55e204080f
  }

}
