import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CartService } from '../cart.service';
import { DataserviceService } from '../dataservice.service';
import { ItemService } from '../item.service';

@Component({
  selector: 'app-women-cat',
  templateUrl: './women-cat.component.html',
  styleUrls: ['./women-cat.component.css']
})
export class WomenCatComponent implements OnInit {

  womenItems: any;
  disc = 30;
  discPrice = 0;
  loggedin: boolean = false;
  counter: number[] = [];
  id: string = "";
  cartObject: object = {};

  constructor(private item: ItemService, private data: DataserviceService, private cart: CartService, private ar: ActivatedRoute) {
    this.id = ar.snapshot.params["id"];
    this.item.getWomenItemsByCat(this.id).subscribe(s => {

      this.womenItems = s;

      this.counter = new Array(this.womenItems.length);
      for (let ctr = 0; ctr < this.womenItems.length; ctr++) {
        this.counter[ctr] = 1;
      }
    });

    if (sessionStorage.getItem('Active User')) {
      this.loggedin = true
    }
  }
  ngOnInit(): void {
  }

  addtoCart(w: any, idx: number) {

    if (this.loggedin) {
      this.discPrice = w.price;

      if (this.counter[idx] > w.quantity) {
        alert("Not enough Stock")
      }
      else {
        if (this.disc > 0) {
          this.discPrice = w.price - (w.price * (this.disc / 100))
        }
        this.cartObject = {
          totalPrice: this.discPrice * this.counter[idx],
          quantity: this.counter[idx],
          gearId: null,
          sportsWearId: w.itemId,
          userId: this.data.tokenUserId
        }
        // console.log(this.cartObject);

        this.cart.postCartItem(this.cartObject).subscribe();
        this.data.cartItems++;
        sessionStorage.removeItem('Items-In-Cart');
        sessionStorage.setItem('Items-In-Cart', JSON.stringify(this.data.cartItems));

        // console.log(this.data.cartItems);
      }
    }

  }

  plus(i: number) {
    this.counter[i]++;
  }
  minus(i: number) {
    if (this.counter[i] >= 2) {
      this.counter[i]--;
    }
  }
}
