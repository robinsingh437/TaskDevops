import { Component, OnInit } from '@angular/core';
import { DataserviceService } from '../dataservice.service';
import { ProfileService } from '../profile.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  history:any;
  userDetails:any;
  userId:any;
  constructor(private profile : ProfileService, user:UserService, private data:DataserviceService) { 
this.userId=data.tokenUserId;
    profile.getUserData().subscribe(p=>this.history=p);
    profile.getUserDataById(this.userId).subscribe(u=>{
      this.userDetails=u;
      // console.log(this.userDetails); 
    });
    

  }

  ngOnInit(): void {
  }

}
