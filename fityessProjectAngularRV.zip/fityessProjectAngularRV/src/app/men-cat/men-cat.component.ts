import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CartService } from '../cart.service';
import { DataserviceService } from '../dataservice.service';
import { ItemService } from '../item.service';

@Component({
  selector: 'app-men-cat',
  templateUrl: './men-cat.component.html',
  styleUrls: ['./men-cat.component.css']
})
export class MenCatComponent implements OnInit {

  menItems: any;
  disc = 20;
  discPrice = 0;
  cartObject: object = {};
  counter: number[] = [];
  loggedin: boolean = false;
  id:string="";

  constructor(private item: ItemService, private data: DataserviceService, private cart: CartService, private ar : ActivatedRoute) {
    this.id = ar.snapshot.params["id"];
    
    this.item.getMenItemsByCat(this.id).subscribe(s => {

      
      this.menItems = s;
      this.counter = new Array(this.menItems.length);
      for (let ctr = 0; ctr < this.menItems.length; ctr++) {
        this.counter[ctr] = 1;
      }
    });

    if (sessionStorage.getItem('Active User')) {
      this.loggedin = true
    }

  }

  ngOnInit(): void {
  }
  addtoCart(m: any, idx: number) {

    if (this.loggedin) {
      this.discPrice = m.price;

      if (this.counter[idx] > m.quantity) {
        alert("Not enough Stock")
      }
      else {
        if (this.disc > 0) {
          this.discPrice = m.price - (m.price * (this.disc / 100))
        }
        this.cartObject = {
          totalPrice: this.discPrice * this.counter[idx],
          quantity: this.counter[idx],
          gearId: null,
          sportsWearId: m.itemId,
          userId: this.data.tokenUserId
        }
        // console.log(this.cartObject);

        this.cart.postCartItem(this.cartObject).subscribe();
        this.data.cartItems++;
        sessionStorage.removeItem('Items-In-Cart');
        sessionStorage.setItem('Items-In-Cart',JSON.stringify(this.data.cartItems));

        // console.log(this.data.cartItems);

      }
    }
  }

  plus(i: number) {
    this.counter[i]++;
  }
  minus(i: number) {
    if (this.counter[i] >= 2) {
      this.counter[i]--;
    }
  }
}
