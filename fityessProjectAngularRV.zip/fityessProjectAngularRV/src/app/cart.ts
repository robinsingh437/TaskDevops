export class Cart{
    totalPrice? : number;
    quantity? : number; 
    gearId? : number; 
    sportsWearId? : number; 
    userId? : string; 
    orderId? : number;
}