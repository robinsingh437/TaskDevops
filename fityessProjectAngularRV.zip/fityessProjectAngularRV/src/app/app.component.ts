import { Component } from '@angular/core';
import { DataserviceService } from './dataservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'FitnessProjectAngular';
  cartBadge:any;
  // loggedInUser?:string;
  str:string="";
  role:string="";
  constructor(private data:DataserviceService){ 
    if(sessionStorage.getItem('Active User')){
      this.data.tokenUserId=JSON.parse(sessionStorage.getItem('Active User') || '{}');
      // this.loggedInUser=JSON.parse(this.loggedInUser);

      this.data.cartItems=JSON.parse(sessionStorage.getItem('Items-In-Cart') || '{}');
      data.role=JSON.parse(sessionStorage.getItem('Role') || '{}')

    }
  }

  ngDoCheck(){
    this.str=this.data.tokenUserId;
    this.cartBadge=this.data.cartItems;
    // console.log(this.str);
    // console.log(this.cartBadge);
    this.role=this.data.role;
  }

  ngOnIt(){
   
  }

  logout(){
    this.str=''
    sessionStorage.removeItem('Active User');
    sessionStorage.removeItem('Items-In-Cart');
    sessionStorage.removeItem('Role');
  }

  onActivate(event:any) {
    window.scroll(0,0);
    
}

}
