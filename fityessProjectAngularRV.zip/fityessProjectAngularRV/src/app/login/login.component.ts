import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { DataserviceService } from '../dataservice.service';
import { Md5 } from 'ts-md5';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userForm: FormGroup;
  userDetails: any;
  token: any;
  cartItems: any;
  cartPrice: any;
  constructor(private fb: FormBuilder, private user: UserService, private rt: Router, private userToken: DataserviceService,
    private cart: CartService) {
    this.userForm = this.fb.group({
      userId: ["", Validators.required],
      pass: ["", Validators.required],
    });
  }

  ngOnInit(): void { }

  onSubmit(data: any) {
    // console.log(data);
    const md5 = new Md5();
    data.pass = md5.appendStr(data.pass).end();
    // console.log(data);

    this.user.getUser(data.userId, data.pass).subscribe(p => {
      // console.log(p);
      this.userDetails = p;

      if (this.userDetails != null) {   // correct credentials
        sessionStorage.setItem('Active User', JSON.stringify(this.userDetails.userId));
        this.token = this.userDetails.firstName;
        this.userToken.tokenName = this.token;
        this.userToken.tokenUserId = this.userDetails.userId;
        this.cart.getCart().subscribe(c => {
          this.cartItems = c;
          this.userToken.cartItems = this.cartItems.length;
          for (let i = 0; i < this.cartItems.length; i++) {
            this.cartPrice += this.cartItems[i].totalPrice;
          }
          sessionStorage.setItem('Items-In-Cart', JSON.stringify(this.userToken.cartItems))
          if (this.userDetails.role == 'A') {
            this.userToken.role = this.userDetails.role;
            sessionStorage.setItem('Role', JSON.stringify(this.userToken.role))
          }
          else {
            this.userToken.role = this.userDetails.role;
            sessionStorage.setItem('Role', JSON.stringify(this.userToken.role))

          }
        });

      }
      else {

        // incorrect credentials
        this.token = "Not Found";
        this.userToken.tokenName = ""
        this.userToken.tokenUserId = ""

      }

      // new correct user

      if (sessionStorage.getItem('Active User') != null && this.token != "Not Found") {
        // console.log(sessionStorage.getItem('Active User'));

        if (!sessionStorage.getItem('Active User') == this.userDetails.userId) {
          sessionStorage.removeItem('Active User');
          sessionStorage.setItem('Active User', JSON.stringify(this.userDetails.userId))
          console.log(sessionStorage.getItem('Active User'))
          this.token = this.userDetails.firstName;
          this.userToken.tokenName = this.token;
          this.userToken.tokenUserId = this.userDetails.userId;
          this.cart.getCart().subscribe(c => {
            this.cartItems = c;
            this.userToken.cartItems = this.cartItems.length;
            for (let i = 0; i < this.cartItems.length; i++) {
              this.cartPrice += this.cartItems[i].totalPrice;
            }
            sessionStorage.setItem('Items-In-Cart', JSON.stringify(this.userToken.cartItems))
            if (this.userDetails.role == 'A') {
              this.userToken.role = this.userDetails.role;
              sessionStorage.setItem('Role', JSON.stringify(this.userToken.role))
            }
          });

        }
        this.rt.navigate(['./']);
      }
    });
  }
}

