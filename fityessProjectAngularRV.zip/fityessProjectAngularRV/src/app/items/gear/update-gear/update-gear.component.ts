import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ItemService } from 'src/app/item.service';

@Component({
  selector: 'app-update-gear',
  templateUrl: './update-gear.component.html',
  styleUrls: ['./update-gear.component.css']
})
export class UpdateGearComponent implements OnInit {

  id: string;
  gearItem: any;
  gearForm: FormGroup;
  constructor(private item: ItemService, ar: ActivatedRoute, private fb: FormBuilder, private rt: Router) {
    this.gearForm = this.fb.group({
      type: ["", Validators.required],
      itemDescription: ["", Validators.required],
      price: ["", Validators.required],
      imageUrl: ["", Validators.required],
      quantity: ["", Validators.required],
    });

    this.id = ar.snapshot.params["id"];
    this.item.getGearById(this.id).subscribe(g => {
      this.gearItem = g;
      // console.log(this.gearItem) 
    });
  }

  ngOnInit(): void {
  }

  onSubmit(gear: any) {
    // console.log(gear);
    gear.itemId = this.id;
    this.item.putGearData(gear, this.id).subscribe(g => {
      // console.log(g);
    });
    this.rt.navigate(['./items/gear/display']);
  }

}
