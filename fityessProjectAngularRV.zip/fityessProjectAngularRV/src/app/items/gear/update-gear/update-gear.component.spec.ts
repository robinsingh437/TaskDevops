import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateGearComponent } from './update-gear.component';

describe('UpdateGearComponent', () => {
  let component: UpdateGearComponent;
  let fixture: ComponentFixture<UpdateGearComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateGearComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateGearComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
