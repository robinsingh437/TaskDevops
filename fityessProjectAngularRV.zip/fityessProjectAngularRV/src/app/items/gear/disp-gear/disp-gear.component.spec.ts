import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DispGearComponent } from './disp-gear.component';

describe('DispGearComponent', () => {
  let component: DispGearComponent;
  let fixture: ComponentFixture<DispGearComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DispGearComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DispGearComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
