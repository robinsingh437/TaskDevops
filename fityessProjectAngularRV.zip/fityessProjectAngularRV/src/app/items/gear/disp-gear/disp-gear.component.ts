import { Component, OnInit } from '@angular/core';
import { ItemService } from 'src/app/item.service';

@Component({
  selector: 'app-disp-gear',
  templateUrl: './disp-gear.component.html',
  styleUrls: ['./disp-gear.component.css']
})
export class DispGearComponent implements OnInit {

  gearItems:any;

  constructor(private item: ItemService) {
    item.getGearItems().subscribe(s=>this.gearItems=s);
   }

  ngOnInit(): void {
  }

}
