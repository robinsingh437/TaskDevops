import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ItemService } from 'src/app/item.service';

@Component({
  selector: 'app-post-gear',
  templateUrl: './post-gear.component.html',
  styleUrls: ['./post-gear.component.css']
})
export class PostGearComponent implements OnInit {


  gearForm:FormGroup;
  imgurl:string='';
  constructor(private item:ItemService, private fb:FormBuilder, private rt:Router) {
    this.gearForm = this.fb.group({
      type: ["", Validators.required],
      itemDescription: ["", Validators.required],
      price: ["", Validators.compose([
        Validators.required,
        Validators.min(1)
      ])],
      imageUrl: ["", Validators.required],
      quantity: ["", Validators.compose([
        Validators.required,
        Validators.min(1)
      ])],
    });
  }

  ngOnInit(): void {
  }

  onSubmitGear(data: any) {
    this.item.postGearData(data).subscribe(p => {
      // console.log(p);
    });
    this.rt.navigate(['./items/gear/display']);
  }
}
