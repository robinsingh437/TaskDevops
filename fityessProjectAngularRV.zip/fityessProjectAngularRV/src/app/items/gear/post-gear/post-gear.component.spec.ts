import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PostGearComponent } from './post-gear.component';

describe('PostGearComponent', () => {
  let component: PostGearComponent;
  let fixture: ComponentFixture<PostGearComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PostGearComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PostGearComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
