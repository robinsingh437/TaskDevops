import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ItemService } from 'src/app/item.service';

@Component({
  selector: 'app-delete-gear',
  templateUrl: './delete-gear.component.html',
  styleUrls: ['./delete-gear.component.css']
})
export class DeleteGearComponent implements OnInit {

  id: string;
  gearItem: any;
  constructor(private item: ItemService, ar: ActivatedRoute, private rt: Router) {
    this.id = ar.snapshot.params["id"];
    this.item.getGearById(this.id).subscribe(g => {
      this.gearItem = g;
      // console.log(this.gearItem);
    });
  }

  ngOnInit(): void {
  }

  onDelete() {
    this.item.deleteGearItem(this.id).subscribe(g => {
      this.gearItem = g;
      // console.log("success"); 
      this.rt.navigate(['./items/gear/display']);
    })

  }

}
