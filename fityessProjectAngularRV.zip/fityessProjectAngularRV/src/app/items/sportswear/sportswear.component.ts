import { Component, OnInit } from '@angular/core';
import { ItemService } from 'src/app/item.service';

@Component({
  selector: 'app-sportswear',
  templateUrl: './sportswear.component.html',
  styleUrls: ['./sportswear.component.css']
})
export class SportswearComponent implements OnInit {

  constructor(){ }

  ngOnInit(): void {
  }

}
