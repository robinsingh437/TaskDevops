import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatesportswearComponent } from './updatesportswear.component';

describe('UpdatesportswearComponent', () => {
  let component: UpdatesportswearComponent;
  let fixture: ComponentFixture<UpdatesportswearComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdatesportswearComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatesportswearComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
