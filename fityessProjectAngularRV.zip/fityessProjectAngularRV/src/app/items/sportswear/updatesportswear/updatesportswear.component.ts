import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ItemService } from 'src/app/item.service';

@Component({
  selector: 'app-updatesportswear',
  templateUrl: './updatesportswear.component.html',
  styleUrls: ['./updatesportswear.component.css']
})
export class UpdatesportswearComponent implements OnInit {

  id: string;
  sportswearItem: any;
  itemForm: FormGroup;
  constructor(private item:ItemService, ar: ActivatedRoute, private fb:FormBuilder, private rt:Router) { 
    this.itemForm = this.fb.group({
      gender: ["", Validators.required],
      type: ["", Validators.required],
      price: ["", Validators.required],
      size: ["", Validators.required],
      itemDescription: ["", Validators.required],
      imageUrl: ["", Validators.required],
      quantity: ["", Validators.required]
    });

    this.id = ar.snapshot.params["id"];
    this.item.getSportsWearById(this.id).subscribe(s => { this.sportswearItem = s; 
      // console.log(this.sportswearItem) 
    });
  }

  ngOnInit(): void {
  }

  onSubmit(sportswear:any) {
    console.log(sportswear);
    sportswear.itemId=this.id;
      this.item.putSportsWearData(sportswear,this.id).subscribe(s => {
        // console.log(s);
      });
      this.rt.navigate(['./items/sportswear/display']);
  }

  
}
