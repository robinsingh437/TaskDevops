import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ItemService } from 'src/app/item.service';

@Component({
  selector: 'app-post-sportswear',
  templateUrl: './post-sportswear.component.html',
  styleUrls: ['./post-sportswear.component.css']
})
export class PostSportswearComponent implements OnInit {

  itemForm:FormGroup;
imgurl:string='';

  constructor(private item:ItemService, private fb:FormBuilder, private rt: Router) {

    this.itemForm = this.fb.group({
      gender: ["", Validators.required],
      type: ["", Validators.required],
      price: ["", Validators.compose([
        Validators.required,
        Validators.min(1)
      ])],
      size: ["", Validators.required],
      itemDescription: ["", Validators.required],
      imageUrl: ["", Validators.required],
      quantity: ["", Validators.compose([
        Validators.required,
        Validators.min(1)
      ])]
    });

   }

  ngOnInit(): void {
  }
  onSubmit(data: any) {
    this.item.postSportsWearData(data).subscribe(p => {
      // console.log(p);
    });
    this.rt.navigate(['./items/sportswear/display']);
  }

}
