import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PostSportswearComponent } from './post-sportswear.component';

describe('PostSportswearComponent', () => {
  let component: PostSportswearComponent;
  let fixture: ComponentFixture<PostSportswearComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PostSportswearComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PostSportswearComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
