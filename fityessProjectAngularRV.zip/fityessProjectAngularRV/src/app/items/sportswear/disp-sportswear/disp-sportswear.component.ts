import { Component, OnInit } from '@angular/core';
import { ItemService } from 'src/app/item.service';

@Component({
  selector: 'app-disp-sportswear',
  templateUrl: './disp-sportswear.component.html',
  styleUrls: ['./disp-sportswear.component.css']
})
export class DispSportswearComponent implements OnInit {

  sportswearItems:any;

  constructor(private item: ItemService) {
    item.getSportsWearItems().subscribe(s=>this.sportswearItems=s);
   }

  ngOnInit(): void {
  }

}
