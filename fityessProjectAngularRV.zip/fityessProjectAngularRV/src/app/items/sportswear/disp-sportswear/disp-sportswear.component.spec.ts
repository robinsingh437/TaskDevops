import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DispSportswearComponent } from './disp-sportswear.component';

describe('DispSportswearComponent', () => {
  let component: DispSportswearComponent;
  let fixture: ComponentFixture<DispSportswearComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DispSportswearComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DispSportswearComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
