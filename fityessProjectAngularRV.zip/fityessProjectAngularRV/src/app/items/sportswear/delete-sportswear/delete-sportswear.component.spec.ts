import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteSportswearComponent } from './delete-sportswear.component';

describe('DeleteSportswearComponent', () => {
  let component: DeleteSportswearComponent;
  let fixture: ComponentFixture<DeleteSportswearComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteSportswearComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteSportswearComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
