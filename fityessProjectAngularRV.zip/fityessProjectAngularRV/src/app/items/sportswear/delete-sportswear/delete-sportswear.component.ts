import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ItemService } from 'src/app/item.service';

@Component({
  selector: 'app-delete-sportswear',
  templateUrl: './delete-sportswear.component.html',
  styleUrls: ['./delete-sportswear.component.css']
})
export class DeleteSportswearComponent implements OnInit {

  id: string;
  swItem: any;
  constructor(private item: ItemService, ar: ActivatedRoute, private rt: Router) {
    this.id = ar.snapshot.params["id"];
    this.item.getSportsWearById(this.id).subscribe(g => {
      this.swItem = g;
      // console.log(this.swItem) 
    });
  }

  ngOnInit(): void {
  }

  onDelete() {
    this.item.deleteSportsWearItem(this.id).subscribe(g => {
      this.swItem = g;
      // console.log("success"); 
      this.rt.navigate(['./items/sportswear/display']);
    })
  }

}
