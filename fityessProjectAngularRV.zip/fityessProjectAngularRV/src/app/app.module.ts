import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { ItemsComponent } from './items/items.component';
import { SportswearComponent } from './items/sportswear/sportswear.component';
import { GearComponent } from './items/gear/gear.component';
import { DeleteGearComponent } from './items/gear/delete-gear/delete-gear.component';
import { PostGearComponent } from './items/gear/post-gear/post-gear.component';
import { DeleteSportswearComponent } from './items/sportswear/delete-sportswear/delete-sportswear.component';
import { PostSportswearComponent } from './items/sportswear/post-sportswear/post-sportswear.component';
import { DispSportswearComponent } from './items/sportswear/disp-sportswear/disp-sportswear.component';
import { DispGearComponent } from './items/gear/disp-gear/disp-gear.component';
import { UpdateGearComponent } from './items/gear/update-gear/update-gear.component';
import { UpdatesportswearComponent } from './items/sportswear/updatesportswear/updatesportswear.component';
import { MenComponent } from './men/men.component';
import { WomenComponent } from './women/women.component';
import { EquipmentComponent } from './equipment/equipment.component';
import { AboutComponent } from './about/about.component';
import { DiscountPipe } from './discount.pipe';
import { CartComponent } from './cart/cart.component';
import { OrderComponent } from './order/order.component';
import { PnfComponent } from './pnf/pnf.component';
import { ProfileComponent } from './profile/profile.component';
import { MenCatComponent } from './men-cat/men-cat.component';
import { WomenCatComponent } from './women-cat/women-cat.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    HomeComponent,
    LoginComponent,
    ItemsComponent,
    SportswearComponent,
    GearComponent,
    DeleteGearComponent,
    PostGearComponent,
    DeleteSportswearComponent,
    PostSportswearComponent,
    DispSportswearComponent,
    DispGearComponent,
    UpdateGearComponent,
    UpdatesportswearComponent,
    MenComponent,
    WomenComponent,
    EquipmentComponent,
    AboutComponent,
    DiscountPipe,
    CartComponent,
    OrderComponent,
    PnfComponent,
    ProfileComponent,
    MenCatComponent,
    WomenCatComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
