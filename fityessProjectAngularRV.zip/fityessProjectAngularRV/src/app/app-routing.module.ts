import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { ItemsComponent } from './items/items.component';
import { SportswearComponent } from './items/sportswear/sportswear.component';
import { GearComponent } from './items/gear/gear.component';
import { PostSportswearComponent } from './items/sportswear/post-sportswear/post-sportswear.component';
import { DeleteSportswearComponent } from './items/sportswear/delete-sportswear/delete-sportswear.component';
import { PostGearComponent } from './items/gear/post-gear/post-gear.component';
import { DeleteGearComponent } from './items/gear/delete-gear/delete-gear.component';
import { DispSportswearComponent } from './items/sportswear/disp-sportswear/disp-sportswear.component';
import { DispGearComponent } from './items/gear/disp-gear/disp-gear.component';
import { UpdatesportswearComponent } from './items/sportswear/updatesportswear/updatesportswear.component';
import { UpdateGearComponent } from './items/gear/update-gear/update-gear.component';
import { MenComponent } from './men/men.component';
import { WomenComponent } from './women/women.component';
import { EquipmentComponent } from './equipment/equipment.component';
import { AboutComponent } from './about/about.component';
import { CartComponent } from './cart/cart.component';
import { OrderComponent } from './order/order.component';
import { LoginGuard } from './login.guard';
import { AuthGuard } from './auth.guard';
import { PnfComponent } from './pnf/pnf.component';
import { ProfileComponent } from './profile/profile.component';
import { MenCatComponent } from './men-cat/men-cat.component';
import { WomenCatComponent } from './women-cat/women-cat.component';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  {
    path: 'items', component: ItemsComponent, canActivate: [AuthGuard],
    children: [
      { path: '', redirectTo: 'items', pathMatch: 'full' },
      {
        path: 'sportswear', component: SportswearComponent,
        children: [
          { path: '', redirectTo: 'display', pathMatch: 'full' },
          { path: 'display', component: DispSportswearComponent },
          { path: 'post', component: PostSportswearComponent },
          { path: 'display/delete/:id', component: DeleteSportswearComponent },
          { path: 'display/update/:id', component: UpdatesportswearComponent }
        ]
      },
      {
        path: 'gear', component: GearComponent,
        children: [
          { path: '', redirectTo: 'display', pathMatch: 'full' },
          { path: 'display', component: DispGearComponent },
          { path: 'post', component: PostGearComponent },
          { path: 'display/delete/:id', component: DeleteGearComponent },
          { path: 'display/update/:id', component: UpdateGearComponent }
        ]
      }
    ]
  },
  { path: 'men', component: MenComponent },
  { path: 'men/:id', component: MenCatComponent },
  { path: 'women', component: WomenComponent },
  { path: 'women/:id', component: WomenCatComponent },
  { path: 'equipment', component: EquipmentComponent },
  { path: 'about', component: AboutComponent },
  { path: 'cart', component: CartComponent, canActivate: [LoginGuard] },
  { path: 'order', component: OrderComponent, canActivate: [LoginGuard] },
  { path: 'profile', component: ProfileComponent, canActivate: [LoginGuard] },
  { path: '**', component: PnfComponent }
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
