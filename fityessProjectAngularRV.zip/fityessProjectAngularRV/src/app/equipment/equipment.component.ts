import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { DataserviceService } from '../dataservice.service';
import { ItemService } from '../item.service';

@Component({
  selector: 'app-equipment',
  templateUrl: './equipment.component.html',
  styleUrls: ['./equipment.component.css']
})
export class EquipmentComponent implements OnInit {

  gearItems: any;
  // discountedPrice:number;
  disc = 20;
  discPrice = 0;
  cartObject: object = {};
  counter: number[] = [];
  loggedin: boolean = false;


  constructor(private item: ItemService, private data: DataserviceService, private cart: CartService) {
    this.item.getGearItems().subscribe(s => {
      this.gearItems = s;
      this.counter = new Array(this.gearItems.length);
      for (let ctr = 0; ctr < this.gearItems.length; ctr++) {
        this.counter[ctr] = 1;
      }
    });

    if (sessionStorage.getItem('Active User')) {
      this.loggedin = true
    }

    // this.discountedPrice=(this.gearItems.price)-(this.gearItems.price*(this.discount/100));


  }

  ngOnInit(): void {
  }

  addtoCart(g: any, idx: number) {
    if (this.loggedin) {
      this.discPrice = g.price;
      // console.log(g.quantity)

      if (this.counter[idx] > g.quantity) {
        alert("Not enough Stock")
      }
      else {
        if (this.disc > 0) {
          this.discPrice = g.price - (g.price * (this.disc / 100))
        }
        this.cartObject = {
          totalPrice: this.discPrice * this.counter[idx],
          quantity: this.counter[idx],
          gearId: g.itemId,
          sportsWearId: null,
          userId: this.data.tokenUserId
        }
        // console.log(this.cartObject);

        this.cart.postCartItem(this.cartObject).subscribe();

        this.data.cartItems++;
        sessionStorage.removeItem('Items-In-Cart');
        sessionStorage.setItem('Items-In-Cart',JSON.stringify(this.data.cartItems));

        // console.log(this.data.cartItems);
      }
    }




  }

  plus(i: number) {
    this.counter[i]++;
  }
  minus(i: number) {
    if (this.counter[i] >= 2) {
      this.counter[i]--;
    }
  }

}
