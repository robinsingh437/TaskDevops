import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DataserviceService } from './dataservice.service';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  constructor( private http:HttpClient, private data:DataserviceService) { }

getUserData(){
  return this.http.get( 'http://localhost:55575/api/profile/' +this.data.tokenUserId)
}
getUserDataById(id:string){
  return this.http.put('http://localhost:55575/api/profile/'+id, null)
}

}
